<?php

namespace PowerBoard\Controllers\Admin;

class SettingsController {

}
